package kr.co.ehr;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;

import kr.co.ehr.user.service.Level;
import kr.co.ehr.user.service.User;
import kr.co.ehr.user.service.UserDao;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml"
								  ,"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"})
public class UserWebTest {
	private Logger LOG = LoggerFactory.getLogger(UserWebTest.class);
	
	@Autowired
	private UserDao dao;
	
	@Autowired
	WebApplicationContext context;
	List<User> users;
	
	private MockMvc mockMvc; //리퀘스트 호출할 부분
	
	@Before
	public void setUp() {
		LOG.debug("^^^^^^^^^^^^^^^^^^");
		LOG.debug("setUp()");
		LOG.debug("^^^^^^^^^^^^^^^^^^");
		
		users = Arrays.asList(
				new User("j01_126","강슬기01","1234",Level.BASIC,49,0,"glwlzkwp@naver.com","2019/08/23")
				,new User("j02_126","강슬기02","1234",Level.BASIC,50,0,"glwlzkwp@naver.com","2019/08/23") //BASIC -> SILVER
				,new User("j03_126","강슬기03","1234",Level.SILVER,50,29,"glwlzkwp@naver.com","2019/08/23")
				,new User("j04_126","강슬기04","1234",Level.SILVER,50,30,"glwlzkwp@naver.com","2019/08/23") //SILVER -> GOLD
				,new User("j05_126","강슬기05","1234",Level.GOLD,99,99,"glwlzkwp@naver.com","2019/08/23")
				);
		
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
		
		LOG.debug("==============================");
		LOG.debug("=context="+context);
		LOG.debug("=mockMvc="+mockMvc);
		LOG.debug("=dao="+dao);
		LOG.debug("==============================");
		
		
	}
	
	
	//CRUD
	@Test
	@Ignore
	public void addAndGet() throws Exception {
		LOG.debug("======================");
		LOG.debug("=01.기존 데이터 삭제=");
		LOG.debug("======================");
		for(User user:users) {
			do_delete(user);
		}
		
		
		LOG.debug("======================");
		LOG.debug("=02.단건등록=");
		LOG.debug("======================");
		for(User user:users) {
			do_insert(user);
		}
		assertThat(dao.count("_126"), is(5));

		
		LOG.debug("======================");
		LOG.debug("=03.단건조회=");
		LOG.debug("======================");
		for(User user:users) {
			User vsUser = get_selectOne(user);
			checkUser(vsUser,user);
		}
		
		
	}
	
	
	@Test
	@Ignore
	public void updateUser() throws Exception {
		LOG.debug("======================");
		LOG.debug("=01.기존 데이터 삭제=");
		LOG.debug("======================");
		for(User user:users) {
			do_delete(user);
		}
		
		LOG.debug("======================");
		LOG.debug("=01.데이터입력=");
		LOG.debug("======================");
		do_insert(users.get(0));
		
		
		User user01 = users.get(0);
		user01.setName("케이트 블란쳇");
		user01.setPasswd("1234U");
		user01.sethLevel(Level.GOLD);
		user01.setLogin(99);
		user01.setRecommend(999);
		user01.setEmail("Uzz@hanmail.net");
		
		
		LOG.debug("======================");
		LOG.debug("=03.입력데이터 수정=");
		LOG.debug("=03.1  수정=");
		LOG.debug("=03.2 업데이트 수행=");
		LOG.debug("======================");
		do_update(user01);
		
		
		LOG.debug("======================");
		LOG.debug("=04.조회 후 데이터비교=");
		LOG.debug("======================");
		User vsUser = get_selectOne(user01);
		checkUser(vsUser, user01);
		
	
	}
	
	
	
	private void checkUser(User vsUser, User user) {
		assertThat(vsUser.getU_id(), is(user.getU_id()));
		assertThat(vsUser.getPasswd(), is(user.getPasswd()));
		assertThat(vsUser.getName(), is(user.getName()));
		assertThat(vsUser.getEmail(), is(user.getEmail()));
		
		assertThat(vsUser.getRecommend(), is(user.getRecommend()));
		assertThat(vsUser.getLogin(), is(user.getLogin()));
		assertThat(vsUser.gethLevel(), is(user.gethLevel()));
		
	}
	
	
	
	
	/**
	 * 단건수정 (오버로드. 같은 메소드 다른 파람)
	 * @param user
	 * @return 
	 * @throws Exception 
	 */
	private void do_update(User user) throws Exception {
		MockHttpServletRequestBuilder createMessage = MockMvcRequestBuilders.post("/user/do_update.do")
													  .param("u_id", user.getU_id())
													  .param("name", user.getName())
													  .param("passwd", user.getPasswd())
													  .param("hLevel", user.gethLevel()+"")
													  .param("login", user.getLogin()+"")
													  .param("recommend", user.getRecommend()+"")
													  .param("email", user.getEmail());
				  
		ResultActions resultActions =mockMvc.perform(createMessage)
									.andExpect(MockMvcResultMatchers.content().contentType("application/json; charset=UTF-8")) //컨텐트타입 검증. 이렇게 나올거야라는 예상.
									;
		
		String result =	resultActions.andDo(print())
				.andReturn()
				.getResponse().getContentAsString();

		LOG.debug("===============================");
		LOG.debug("=result="+result);
		LOG.debug("===============================");	
		
		
	
	}
	
	
	
	
	/**
	 * 단건조회 (오버로드. 같은 메소드 다른 파람)
	 * @param user
	 * @return 
	 * @throws Exception 
	 */
	private User get_selectOne(User user) throws Exception {
		MockHttpServletRequestBuilder createMessage = MockMvcRequestBuilders.post("/user/get_select_one.do")
													  .param("u_id", user.getU_id());
		
		ResultActions resultActions = mockMvc.perform(createMessage)
									.andExpect(MockMvcResultMatchers.content().contentType("application/json; charset=UTF-8")) //컨텐트타입 검증. 이렇게 나올거야라는 예상.
									.andExpect(MockMvcResultMatchers.jsonPath("$.name", is(user.getName()))) //json 수행테스트
									;
		
		String result = resultActions.andDo(print()) //result에 json데이터 들어있음
						.andReturn()
						.getResponse().getContentAsString();
		
		LOG.debug("==============================");
		LOG.debug("=result="+result);
		LOG.debug("==============================");
		
		
		//Json to User
		Gson gson = new Gson();
		User outVO = gson.fromJson(result, User.class);
		
		
		return outVO;
		
	}
	
	
	
	/**
	 * 데이터등록 (오버로드. 같은 메소드 다른 파람)
	 * @param user
	 * @throws Exception 
	 */
	private void do_insert(User user) throws Exception {
		MockHttpServletRequestBuilder createMessage = MockMvcRequestBuilders.post("/user/do_insert.do")
													  .param("u_id", user.getU_id())
													  .param("name", user.getName())
													  .param("passwd", user.getPasswd())
													  .param("hLevel", user.gethLevel()+"")
													  .param("login", user.getLogin()+"")
													  .param("recommend", user.getRecommend()+"")
													  .param("email", user.getEmail());
				  
		ResultActions resultActions =mockMvc.perform(createMessage)
									.andExpect(MockMvcResultMatchers.content().contentType("application/json; charset=UTF-8")) //컨텐트타입 검증. 이렇게 나올거야라는 예상.
									.andExpect(MockMvcResultMatchers.jsonPath("$.msgId", is("1"))) //json 수행테스트
									;
		
		
		String result =	resultActions.andDo(print())
				.andReturn()
				.getResponse().getContentAsString();

		LOG.debug("===============================");
		LOG.debug("=result="+result);
		LOG.debug("===============================");	
		
	
	}
	
	
	
	
	
	/**
	 * 데이터삭제 (오버로드. 같은 메소드 다른 파람)
	 * @param user
	 * @throws Exception 
	 */
	private void do_delete(User user) throws Exception {
		MockHttpServletRequestBuilder createMessage = MockMvcRequestBuilders.post("/user/do_delete.do")
				  .param("u_id", user.getU_id());
		
		ResultActions resultActions = mockMvc.perform(createMessage)
									.andExpect(MockMvcResultMatchers.content().contentType("application/json; charset=UTF-8"))
									;
		
		String result = resultActions.andDo(print())
						.andReturn()
						.getResponse().getContentAsString();
		
		LOG.debug("==============================");
		LOG.debug("=result="+result);
		LOG.debug("==============================");
	}
	
	
	
	
	@Test
	@Ignore
	public void do_update() throws Exception {
		MockHttpServletRequestBuilder createMessage = MockMvcRequestBuilders.post("/user/do_update.do")
													  .param("u_id", "j01_126")
													  .param("name", "강슬기01_99")
													  .param("passwd", "1234_99")
													  .param("hLevel", Level.SILVER+"")
													  .param("login", "4999")
													  .param("recommend", "99")
													  .param("email", "glwlzkwp_99@naver.com");
				  
		ResultActions resultActions =mockMvc.perform(createMessage)
									.andExpect(MockMvcResultMatchers.content().contentType("application/json; charset=UTF-8")) //컨텐트타입 검증. 이렇게 나올거야라는 예상.
									;
		
		String result =	resultActions.andDo(print())
				.andReturn()
				.getResponse().getContentAsString();

		LOG.debug("===============================");
		LOG.debug("=result="+result);
		LOG.debug("===============================");	
		
		
	
	}
	


	@Test
	//@Ignore
	public void do_insert() throws Exception {
		MockHttpServletRequestBuilder createMessage = MockMvcRequestBuilders.post("/user/do_insert.do")
				  .param("u_id", "j01_126")
				  .param("name", "강슬기01")
				  .param("passwd", "1234")
				  .param("hLevel", Level.BASIC+"")
				  .param("login", "49")
				  .param("recommend", "0")
				  .param("email", "glwlzkwp@naver.com");
				  
		ResultActions resultActions =mockMvc.perform(createMessage)
									.andExpect(MockMvcResultMatchers.content().contentType("application/json; charset=UTF-8")) //컨텐트타입 검증. 이렇게 나올거야라는 예상.
									.andExpect(MockMvcResultMatchers.jsonPath("$.msgId", is("1"))) //json 수행테스트
									;
		
		
		String result =	resultActions.andDo(print())
				.andReturn()
				.getResponse().getContentAsString();

		LOG.debug("===============================");
		LOG.debug("=result="+result);
		LOG.debug("===============================");	
		
	
	}
	
	
	
	
	@Test
	@Ignore
	public void do_delete() throws Exception {
		MockHttpServletRequestBuilder createMessage = MockMvcRequestBuilders.post("/user/do_delete.do")
				  .param("u_id", "j01_126");
		
		ResultActions resultActions = mockMvc.perform(createMessage)
									.andExpect(MockMvcResultMatchers.content().contentType("application/json; charset=UTF-8"))
									;
		
		String result = resultActions.andDo(print())
						.andReturn()
						.getResponse().getContentAsString();
		
		LOG.debug("==============================");
		LOG.debug("=result="+result);
		LOG.debug("==============================");
		
		
	}
	
	
	
	
	@Test
	@Ignore
	public void get_selectOne() throws Exception {
		MockHttpServletRequestBuilder createMessage = MockMvcRequestBuilders.post("/user/get_select_one.do")
													  .param("u_id", "j01_126");
		
		ResultActions resultActions = mockMvc.perform(createMessage)
									.andExpect(MockMvcResultMatchers.content().contentType("application/json; charset=UTF-8")) //컨텐트타입 검증. 이렇게 나올거야라는 예상.
									.andExpect(MockMvcResultMatchers.jsonPath("$.name", is("강슬기01"))) //json 수행테스트
									;
		
		String result = resultActions.andDo(print())
						.andReturn()
						.getResponse().getContentAsString();
		
		LOG.debug("==============================");
		LOG.debug("=result="+result);
		LOG.debug("==============================");
		
	}
	
	
	
	@Test
	@Ignore
	public void doUserView() throws Exception {
		//Request call : url, param
		MockHttpServletRequestBuilder createMessage = MockMvcRequestBuilders.get("/user/do_user_view.do99");
		mockMvc.perform(createMessage)
		.andExpect(status().isOk())
		.andExpect(forwardedUrl("/user/user_mng.jsp"))
		.andDo(print())
		;
		
	}
	
	
	
	
	@Test
	@Ignore
	public void instanceTest() {
		LOG.debug("==============================");
		LOG.debug("=instanceTest=");
		LOG.debug("==============================");
	}
	
	
	@After
	public void tearDown() {
		LOG.debug("^^^^^^^^^^^^^^^^^^");
		LOG.debug("tearDown()");
		LOG.debug("^^^^^^^^^^^^^^^^^^");
	}
	
	
}
