package kr.co.ehr;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import kr.co.ehr.cmn.UserExcelWriter;
import kr.co.ehr.code.service.Code;
import kr.co.ehr.user.service.Level;
import kr.co.ehr.user.service.User;
import kr.co.ehr.user.service.impl.CodeDaoImpl;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
@FixMethodOrder(MethodSorters.NAME_ASCENDING) //@Test를 NAME ASC 순으로 진행
public class UserExcelTest {
	private final Logger LOG = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private WebApplicationContext context;
	
	@Autowired
	private UserExcelWriter userExcelWriter;
	
	List<User> users;
	
	List<String> headers;
	
	
	@Before
	public void setUp() {
		headers = Arrays.asList("아이디"
								,"이름"
								,"비번"
								,"레벨"
								,"로그인"
								,"추천"
								,"이메일"
								,"등록일"
								,"레벨값");
		
		users = Arrays.asList(
				new User("j01_126","강슬기01","1234",Level.BASIC,49,0,"glwlzkwp@naver.com","2019/08/23")
				,new User("j02_126","강슬기02","1234",Level.BASIC,50,0,"glwlzkwp@naver.com","2019/08/23") //BASIC -> SILVER
				,new User("j03_126","강슬기03","1234",Level.SILVER,50,29,"glwlzkwp@naver.com","2019/08/23")
				,new User("j04_126","강슬기04","1234",Level.SILVER,50,30,"glwlzkwp@naver.com","2019/08/23") //SILVER -> GOLD
				,new User("j05_126","강슬기05","1234",Level.GOLD,99,99,"glwlzkwp@naver.com","2019/08/23")
				);
	}
	
	
	@Test
	//@Ignore
	public void xlsxWriterGeneralization() {
		userExcelWriter.xlsxWriterGeneralization(users,headers);
	}
	
	
	
	@Test
	@Ignore
	public void valueObjectRefl() {
		Object obj = users.get(0);
		Field[] fileds = obj.getClass().getDeclaredFields();
		for(int i=0; i<fileds.length; i++) {
			Field field = fileds[i];
			
			field.setAccessible(true);
			
			try {
				Object value = field.get(obj);
				LOG.debug(field.getName()+":"+value);
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
			
		}
	}
	
	
	
	/**
	 * Style처리
	 */
	@Test
	@Ignore
	public void xlsxWriterStyle() {
		userExcelWriter.xlsxWriterStyle(users);
	}
	
	
	@Test
	@Ignore
	public void xlsWriter() {
		userExcelWriter.xlsWriter(users);
	}
	
	@Test
	@Ignore
	public void xlsxWriter() {
		userExcelWriter.xlsxWriter(users);
	}

	
	@Test
	@Ignore
	public void csvWriter() {
		userExcelWriter.csvWriter(users);
	}
	

	
	
	@After
	public void tearDown() {
		
	}
	
	@Test
	public void getBean() {
		LOG.debug("======================");
		LOG.debug("=context="+context);
		LOG.debug("=userExcelWriter="+userExcelWriter);
		LOG.debug("======================");
		assertThat(context, is(notNullValue()));
		assertThat(userExcelWriter, is(notNullValue()));
		
	}
	
	
	
	
	
}
