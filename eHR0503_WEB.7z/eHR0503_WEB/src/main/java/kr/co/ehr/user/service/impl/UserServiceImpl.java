package kr.co.ehr.user.service.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.management.RuntimeErrorException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import kr.co.ehr.cmn.ExcelWriter;
import kr.co.ehr.user.service.Level;
import kr.co.ehr.user.service.Search;
import kr.co.ehr.user.service.User;
import kr.co.ehr.user.service.UserDao;
import kr.co.ehr.user.service.UserService;


@Service
public class UserServiceImpl implements UserService {
	private Logger LOG = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private ExcelWriter excelWriter;
	
	@Autowired
	private MailSender mailSender;
	
	public static final int MIN_LOGINCOUNT_FOR_SILVER = 50;
	public static final int MIN_RECCOMEND_FOR_GOLD = 30;
	
	
	@Autowired
	private UserDao userDao; //인터페이스 통해 만들어야함
	
	
	//최초 사용자 베이직 레벨
	public int add(User user) {
		if(null == user.gethLevel()){
			user.sethLevel(Level.BASIC);
		}
		
		return userDao.add(user);
		
	}
	

	
	protected void upgradeLevel(User user) throws SQLException {
		//-----------------------------------
		//트랜잭션 테스트를 위한 소스
		//-----------------------------------
		
		String id="j04_126";
		//예외 던지기
		if(user.getU_id().equals(id)) {
			throw new RuntimeException(id+" 트랜잭션 HR테스트");
		}
		
		user.upgradeLevel(); //VO부분에 기능을 만듦
		userDao.update(user);
		
		sendUpgradeMail(user); //mail send 
	}
	
	
	
	
	/**
	 * 등업 사용자에게 mail전송
	 */
	private void sendUpgradeMail(User user) {
		try {
			//네이버에서 긁어옴
//			POP 서버명 : pop.naver.com
//			SMTP 서버명 : smtp.naver.com 
//			POP포트 : 995, 보안연결(SSL) 필요 
//			SMTP포트 : 465, 보안 연결(SSL) 필요
//			아이디 : glwlzkwp
//			비밀번호 : 네이버 로그인 비밀번호
			
			//보내는 사람
			String host = "smtp.naver.com";
			final String userName = "glwlzkwp";
			final String password = "13965232sj";
			int port = 465;
			
			
			//받는 사람
			String recipient = user.getEmail();
			//제목
			String title = user.getName()+"등업(https://cafe.naver.com/kndjang)";
			//내용
			String contents = user.getU_id()+"님의 등급이 "+user.gethLevel().name()+"로 변경되었습니다.";
			
			//SMTP 서버 설정
			Properties props = System.getProperties();
			props.put("mail.smtp.host", host);
			props.put("mail.smtp.port", port);
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.ssl.enable", "true");
			props.put("mail.smtp.ssl.trust", host);
			
			
			//인증
			Session session = Session.getInstance(props, new Authenticator() {
				String uName = userName;
				String passwd = password;
				
				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(uName, passwd);
				}
				
			});	
			
			
			session.setDebug(true);
			
			
			SimpleMailMessage mimeMessage = new SimpleMailMessage();
			// 보내는 사람
			mimeMessage.setFrom("glwlzkwp@naver.com");
			// 받는사람
			mimeMessage.setTo(recipient);
			// 제목
			mimeMessage.setSubject(title);
			// 내용
			mimeMessage.setText(contents);
			// 전송
			mailSender.send(mimeMessage);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		LOG.debug("======================");
		LOG.debug("=mail send=");
		LOG.debug("======================");
		
	}
	
	
	
	
	/** 기능 뜯어내기  */
	//level upgrade
	//1. 전체 사용자를 조회
	//2. 대상자를 선별
	// 2.1. BASIC사용자, 로그인cnt가 50이상이면 : BASIC -> SILVER
	// 2.2. SILVER사용자, 추천cnt가 300이상이면 : SILVER -> GOLD
	//3. 대상자 업그레이드
	public void tx_upgradeLevels() throws SQLException {
		
		List<User> users =  userDao.getAll();
		for(User user : users) {
			if(canUpgradeLevel(user)==true) {
				upgradeLevel(user);
			}
		}//--for
			
	}
	
	
	
	//업그레이드 대상여부 파악 : true
	private boolean canUpgradeLevel(User user) {
		Level currLevel = user.gethLevel();
		
		switch(currLevel) {
			case BASIC : return (user.getLogin() >= MIN_LOGINCOUNT_FOR_SILVER);
			case SILVER : return (user.getRecommend() >= MIN_RECCOMEND_FOR_GOLD);
			case GOLD : return false;
			default : throw new IllegalArgumentException("Unknown Level:"+currLevel);
		}
		
	}


	@Override
	public int update(User user) {
		return userDao.update(user);
	}


	@Override
	public List<User> retrieve(Search vo) {
		return userDao.retrieve(vo);
	}


	@Override
	public int deleteUser(User user) {
		return userDao.deleteUser(user);
	}


	@Override
	public User get(String id) {
		return userDao.get(id);
	}



	@Override
	public String excelDown(Search vo,String ext) {
		List<String> headers = Arrays.asList("아이디"
											,"이름"
											,"비번"
											,"레벨"
											,"로그인"
											,"추천"
											,"이메일"
											,"등록일"
											,"레벨값");
		
		List<User> list = userDao.retrieve(vo);
		String saveFileNm = "";
		
		if(ext.equalsIgnoreCase("xlsx")) {
			saveFileNm = excelWriter.xlsxWriterGeneralization(list, headers);
		}else if(ext.equalsIgnoreCase("csv")) {
			saveFileNm = excelWriter.csvWriterGeneralization(list, headers);
		}else if(ext.equalsIgnoreCase("xls")) {
			saveFileNm = excelWriter.xlsWriterGeneralization(list, headers);
		}
		
		return saveFileNm;
	}
	
	
	
	
}
