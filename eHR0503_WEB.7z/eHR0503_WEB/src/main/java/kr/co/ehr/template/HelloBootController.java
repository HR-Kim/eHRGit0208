package kr.co.ehr.template;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloBootController {
	private final Logger LOG = LoggerFactory.getLogger(this.getClass());
	
	//http://localhost:8080/ehr/hello/hello_boot_view.do
	@RequestMapping(value="hello/hello_boot_view.do")
	public String helloBootView() {
		LOG.debug("============================");
		LOG.debug("=@Controller=helloBootView()");
		LOG.debug("============================");
		
		return "hello/hello_boot";
	}
	
	
	//http://localhost:8080/ehr/template/boot_list_view.do
	@RequestMapping(value="template/boot_list_view.do")
	public String bootstrapListView() {
		LOG.debug("============================");
		LOG.debug("=@Controller=bootstrapListView()");
		LOG.debug("============================");
		
		return "template/bootstrap_list_template";
	}
	
	
	//http://localhost:8080/ehr/template/boot_form_view.do
	@RequestMapping(value="template/boot_form_view.do")
	public String bootstrapFormView() {
		LOG.debug("============================");
		LOG.debug("=@Controller=bootstrapFormView()");
		LOG.debug("============================");
		
		return "template/bootstrap_form_template";
	}
	
	
	
	
}
