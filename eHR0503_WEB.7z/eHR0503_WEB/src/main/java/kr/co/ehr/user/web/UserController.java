package kr.co.ehr.user.web;

import java.io.File;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;

import com.google.gson.Gson;

import kr.co.ehr.cmn.DTO;
import kr.co.ehr.cmn.Message;
import kr.co.ehr.cmn.StringUtil;
import kr.co.ehr.code.service.Code;
import kr.co.ehr.user.service.CodeService;
import kr.co.ehr.user.service.Search;
import kr.co.ehr.user.service.User;
import kr.co.ehr.user.service.UserService;
import kr.co.ehr.user.service.UserVO;

@Controller
public class UserController {

	Logger LOG = LoggerFactory.getLogger(this.getClass());
	
	@Resource(name="downloadView")
	private View download;
	
	@Autowired
	UserService userService;
	
	@Autowired
	CodeService codeService;
	
	
	//View
	private final String VIEW_NM = "user/user_mng";
	
	
	//excelDown
	@RequestMapping(value="user/exceldown.do", method = RequestMethod.GET)
	public ModelAndView excelDown(HttpServletRequest req, ModelAndView mView) {
		Search search = new Search();
		
		/** 페이지 사이즈 */
		String pageSize = StringUtil.nvl(req.getParameter("pageSize"),"10");
		/** 페이지 번호 */
		String pageNum = StringUtil.nvl(req.getParameter("pageNum"),"1");
		/** 검색조건 */
		String searchDiv = StringUtil.nvl(req.getParameter("searchDiv"),"");
		/** 검색어 */
		String searchWord = StringUtil.nvl(req.getParameter("searchWord"),"");
		
		/** 확장자 */
		String ext = StringUtil.nvl(req.getParameter("ext"));

		
		search.setPageSize(Integer.valueOf(pageSize));
		search.setPageNum(Integer.valueOf(pageNum));
		search.setSearchDiv(searchDiv);
		search.setSearchWord(searchWord);
		
		String saveFileNm = this.userService.excelDown(search,ext); //저장파일명
		String orgFileNm = "사용자관리_"+StringUtil.cureDate("yyyyMMdd")+"."+ext;
		
		mView.setView(download);
		
		File downloadFile = new File(saveFileNm);
		mView.addObject("downloadFile", downloadFile);
		mView.addObject("orgFileNm", orgFileNm);
		
		return mView;
	}
	
	
	
	//화면call
	//http://localhost:8080/ehr/user/do_user_view.do
	@RequestMapping(value="user/do_user_view.do", method = RequestMethod.GET)
	public String doUserView() {
		LOG.debug("========================");
		LOG.debug("=@Controller=doUserView=");
		LOG.debug("========================");
		
		return VIEW_NM;
	}
	
	
	//검색:user/get_retrieve.do
	@RequestMapping(value="user/get_retrieve.do",method=RequestMethod.GET)
	public String getRetrieve(Search search, Model model) {
		LOG.debug("1=========================");
		LOG.debug("1=param="+search);
		LOG.debug("1=========================");
		
		//페이지 사이즈:10
		//페이지 번호:1
		if(search.getPageSize()==0) {
			search.setPageSize(10);
		}

		if(search.getPageNum()==0) {
			search.setPageNum(1);
		}		
		
		search.setSearchDiv(StringUtil.nvl(search.getSearchDiv()));
		search.setSearchWord(StringUtil.nvl(search.getSearchWord()));
		LOG.debug("2=========================");
		LOG.debug("2=param="+search);
		LOG.debug("2=========================");
		model.addAttribute("vo", search);
		//Code:
		Code code=new Code();
		code.setCodeId("PAGE_SIZE");
		//Code정보조회
		List<Code> codeList = (List<Code>) codeService.get_retrieve(code);
		model.addAttribute("codeList", codeList);
		
		
		code.setCodeId("USER_SEARCH");
		//Code정보조회
		List<Code> codeSearchList = (List<Code>) codeService.get_retrieve(code);
		model.addAttribute("codeSearchList", codeSearchList);
		
		
		List<User> list = this.userService.retrieve(search);
		model.addAttribute("list", list);
		
		//총건수
		int totalCnt = 0;
		if(null != list && list.size()>0) {
			totalCnt = list.get(0).getTotalCnt();
		}
		
		model.addAttribute("totalCnt", totalCnt);
		
		
		return VIEW_NM;
	}
	
	
	
	//수정
	@RequestMapping(value="user/do_update.do",method = RequestMethod.POST
			,produces = "application/json; charset=UTF-8")
	@ResponseBody		
	public String do_update(User user) {
		LOG.debug("1=========================");
		LOG.debug("=@Controller=user=="+user);
		LOG.debug("1=========================");
		
		//validation
		int flag = userService.update(user);
		Message message=new Message();
		if(flag>0) {
			message.setMsgId(flag+"");
			message.setMsgMsg(user.getU_id()+"님 수정 되었습니다.");
		}else {
			message.setMsgId(flag+"");
			message.setMsgMsg(user.getU_id()+"님 수정 실패.");			
		}
	
		//JSON
		Gson gson=new Gson();
		String json = gson.toJson(message);
		LOG.debug("2=========================");
		LOG.debug("=@Controller=json=="+json);
		LOG.debug("2=========================");
		return json;		
	}
	
	
	
	
	//등록
	@RequestMapping(value="user/do_insert.do",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
	@ResponseBody
	public String do_insert(User user) {
		LOG.debug("========================");
		LOG.debug("=@Controller=user="+user);
		LOG.debug("========================");
		
		
		//validation
		int flag = userService.add(user);
		Message message = new Message();
		if(flag>0) {
			message.setMsgId(flag+"");
			message.setMsgMsg(user.getU_id()+"님 등록되었습니다.");
		}else {
			message.setMsgId(flag+"");
			message.setMsgMsg(user.getU_id()+"님 등록실패.");
		}
		

		//json으로 변환
		Gson gson = new Gson();
		String json = gson.toJson(message);
		LOG.debug("=========================");
		LOG.debug("=@Controller 등록gson=user=="+json);
		LOG.debug("=========================");		
		
		
		return json;
	}
	
	
	
	
	//삭제
	@RequestMapping(value="user/do_delete.do",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
	@ResponseBody
	public String do_delete(User user) {
		LOG.debug("========================");
		LOG.debug("=@Controller=user="+user);
		LOG.debug("========================");
		
		//flag>0 성공, 실패
		int flag = userService.deleteUser(user);
		Message message = new Message();
		if(flag>0) {
			message.setMsgId(flag+"");
			message.setMsgMsg("삭제되었습니다.");
		}else {
			message.setMsgId(flag+"");
			message.setMsgMsg("삭제실패.");
		}
		
		
		//json으로 변환
		Gson gson = new Gson();
		String json = gson.toJson(message);
		LOG.debug("=========================");
		LOG.debug("=@Controller 삭제gson=user=="+json);
		LOG.debug("=========================");		
		
		return json;
	}
	
	
	
	
	//단건조회
	@RequestMapping(value="user/get_select_one.do",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
	@ResponseBody
	public String get_selectOne(User user,Model model) {
		LOG.debug("=========================");
		LOG.debug("=@Controller=user=="+user);
		LOG.debug("=========================");
		
		if(user.getU_id() == null || "".equals(user.getU_id())) {
			throw new IllegalArgumentException("아이디를 입력하세요.");
		}
		
		User outVO = userService.get(user.getU_id());
		//BASIC -> 1
		outVO.setLevel(outVO.gethLevel().intValue());

		Gson gson=new Gson();
		String json = gson.toJson(outVO);
		LOG.debug("=========================");
		LOG.debug("=@Controller gson=user=="+json);
		LOG.debug("=========================");		
		
		return json;
	}
	
	
	
}
