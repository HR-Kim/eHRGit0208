package kr.co.ehr.user.service;

import kr.co.ehr.cmn.DTO;

public class UserVO extends DTO {
	
	/** 이름 */
	private String name	;
	/** 성별 */
	private String sex	;
	/** 전화 */
	private String tel	;
	/** 나이 */
	private String age	;
	/** 휴대전화 */
	private String cellPhone	;
	
	
	
	public UserVO() {}



	public UserVO(String name, String sex, String tel, String age, String cellPhone) {
		super();
		this.name = name;
		this.sex = sex;
		this.tel = tel;
		this.age = age;
		this.cellPhone = cellPhone;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getSex() {
		return sex;
	}



	public void setSex(String sex) {
		this.sex = sex;
	}



	public String getTel() {
		return tel;
	}



	public void setTel(String tel) {
		this.tel = tel;
	}



	public String getAge() {
		return age;
	}



	public void setAge(String age) {
		this.age = age;
	}



	public String getCellPhone() {
		return cellPhone;
	}



	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}



	@Override
	public String toString() {
		return "UserVO [name=" + name + ", sex=" + sex + ", tel=" + tel + ", age=" + age + ", cellPhone=" + cellPhone
				+ "]";
	}


	
	
}
